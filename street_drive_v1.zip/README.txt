STREET DRIVE — Versioni 1.0
1. Hap index.html në Safari/Chrome.
2. Në iPhone mund ta hapësh dhe me Share → Add to Home Screen.
3. Kontrollet: ◀ ▶ për drejtim, GAZ për shpejtësi.
