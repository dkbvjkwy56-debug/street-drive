STREET DRIVE V2
================
Open index.html in a browser, or upload the folder to GitHub Pages.

V2 features:
- iPhone touch controls
- Left/right steering
- BOOST button
- Traffic cars
- Collectible coins
- Score counter
- Collision + restart
- Responsive mobile/desktop layout
