STREET DRIVE V5
================
Version upgraded from the supplied V2.

Features:
- Improved pseudo-3D road perspective
- Day/Night mode
- iPhone touch controls
- Left/right steering
- BOOST
- Traffic cars
- Collectible coins
- Score + best score saved locally
- Collision + restart
- Responsive mobile/desktop layout
- Roadside lamps/buildings
- Ready for GitHub Pages

To test:
1. Extract the ZIP.
2. Open index.html in a browser.
3. For iPhone/public play, upload the files to GitHub Pages.
